package farm

case class FarmTask(animal: Animal, description: String, duration: Int)
