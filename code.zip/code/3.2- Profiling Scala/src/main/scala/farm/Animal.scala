package farm

case class Animal(name: String, age: Int, species: Species)